"""
abs_scatter_analysis.py
=======================
SEC ABS Auto Loan Pool Analysis — Cash Collection Scatter Plot
Author : [Your Name], University of Georgia
Advisor: Dr. Pekka Honkanen
Date   : May 2026

Description
-----------
Scrapes structured data from SEC EDGAR ABS-EE filings for U.S. auto loan
asset-backed securities (ABS) pools and produces a scatter plot comparing
annual interest collections against total principal collections, colour-coded
by issuing brand.

Data sources
------------
  * output/final_abs_summary_dr_honkanen.csv
      Monthly cash-flow summary per pool, derived from SEC ABS-EE XML filings.
      Columns used: company_name / poolname, date, totalInterest,
      principalCollections, prepaymentsInFullCollected, recoveries,
      liquidationProceeds, totalPrincipal.

  * output/metadata.csv
      Maps SEC accession numbers to pool names and reporting periods.
      Produced by the companion scraper (scrape_sec_abs.py).

  * output/table_4_noteholder.csv  /  output/table_5_note_balance.csv
      Raw structured tables extracted from SEC EDGAR filings, used to
      identify cleanup-call events and initial pool sizes.

Output
------
  output/analysis_v7/01_scatter_by_brand.png   — main scatter plot

Key design choices
------------------
  * X-axis  : Annual TOTAL principal collections per pool-year
              = scheduled amortisation + voluntary prepayments +
                recoveries + liquidation proceeds.
              Using only scheduled amortisation would severely understate
              cash flows in pools with high prepayment speeds (CPR).

  * Y-axis  : Annual interest collections per pool-year.

  * Ratio interpretation:  Interest / Total_Principal is NOT the WAC.
              It is a cash-flow yield proxy that varies with prepayment speed.
              Prime pools (fast CPR → large X denominator) plot near or below
              the 5 % guide line.  Subprime pools (slow CPR, high WAC) plot
              well above it — see Santander cluster.

  * Filters :
      - Pool-years with < 6 monthly observations excluded (partial-year bias).
      - Pool-years with implied interest/principal ratio > 30 % excluded
        (likely data-entry errors in the source filings).

Requirements
------------
  pip install pandas numpy matplotlib
  Python 3.9+

Usage
-----
  python abs_scatter_analysis.py
"""

import pandas as pd
import numpy as np
import os
import re
import sys
import matplotlib
matplotlib.use('Agg')          # non-interactive backend; remove for Jupyter
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
OUT = 'output/analysis_v7'
os.makedirs(OUT, exist_ok=True)

# Dark institutional theme
plt.style.use('dark_background')
plt.rcParams.update({
    'font.size': 12,
    'axes.labelsize': 13,
    'axes.titlesize': 15,
    'xtick.labelsize': 11,
    'ytick.labelsize': 11,
    'legend.fontsize': 9,
    'axes.grid': True,
    'grid.alpha': 0.18,
    'axes.edgecolor': '#444444',
    'figure.facecolor': '#0d0d0d',
    'axes.facecolor': '#111111',
})

# ---------------------------------------------------------------------------
# Brand colour palette
# ---------------------------------------------------------------------------
BRAND_COLORS = {
    'ALLY':        '#ffcc00',
    'BMW':         '#0099cc',
    'BRIDGECREST': '#55ff55',
    'CALIFORNIA':  '#99cc00',
    'CAPITAL':     '#009900',
    'CARMAX':      '#00ffcc',
    'CARVANA':     '#00aae7',
    'DRIVE':       '#ff44aa',
    'EXETER':      '#ff8800',
    'FIFTH':       '#4488ff',
    'FORD':        '#ff5533',
    'GM/AMERI':    '#cc0000',
    'HARLEY':      '#ff6600',
    'HONDA':       '#ff33ff',
    'HUNTINGTON':  '#44cc44',
    'HYUNDAI':     '#33cc33',
    'MERCEDES':    '#aaaaaa',
    'NISSAN':      '#ff6699',
    'SANTANDER':   '#ff0000',
    'TOYOTA':      '#e8b800',
    'USAA':        '#003388',
    'VW':          '#0077cc',
    'WORLD':       '#66ccff',
}

def brand_color(b: str) -> str:
    """Return hex colour for a brand label, defaulting to grey."""
    return BRAND_COLORS.get(str(b).upper(), '#888888')


# ---------------------------------------------------------------------------
# Brand classification
# ---------------------------------------------------------------------------
def get_brand(name: str) -> str:
    """
    Map a full SEC pool/trust name to a short brand label.
    Returns 'OTHER' for names that don't match any known issuer.
    """
    if pd.isna(name):
        return 'OTHER'
    s = str(name).upper()
    if 'CARMAX'      in s: return 'CARMAX'
    if 'FORD'        in s: return 'FORD'
    if 'BMW'         in s: return 'BMW'
    if 'TOYOTA'      in s: return 'TOYOTA'
    if 'HONDA'       in s: return 'HONDA'
    if 'NISSAN'      in s: return 'NISSAN'
    if 'HYUNDAI'     in s: return 'HYUNDAI'
    if 'MERCEDES'    in s: return 'MERCEDES'
    if 'VOLKSWAGEN'  in s or ('VW' in s and 'AUTO' in s): return 'VW'
    if 'ALLY'        in s: return 'ALLY'
    if 'CAPITAL ONE' in s or 'CAP ONE' in s: return 'CAPITAL'
    if 'FIFTH THIRD' in s or 'FIFTH'   in s: return 'FIFTH'
    if 'CHASE'       in s: return 'CHASE'
    if 'HARLEY'      in s: return 'HARLEY'
    if 'WORLD OMNI'  in s or 'WORLD'   in s: return 'WORLD'
    if 'SANTANDER'   in s: return 'SANTANDER'
    if 'AMERICREDIT' in s or 'GM FINANCIAL' in s: return 'GM/AMERI'
    if 'DRIVE'       in s: return 'DRIVE'
    if 'CARVANA'     in s: return 'CARVANA'
    if 'USAA'        in s: return 'USAA'
    if 'EXETER'      in s: return 'EXETER'
    if 'HUNTINGTON'  in s: return 'HUNTINGTON'
    if 'BANK OF AMERICA' in s: return 'BOA'
    if 'CALIFORNIA'  in s: return 'CALIFORNIA'
    if 'HSBC'        in s: return 'HSBC'
    if 'BRIDGECREST' in s: return 'BRIDGECREST'
    return 'OTHER'


# ---------------------------------------------------------------------------
# Utility: parse currency strings from SEC table cells
# ---------------------------------------------------------------------------
def clean_money(x) -> float:
    """Convert a raw SEC table value (string or float) to a Python float."""
    if pd.isna(x):
        return np.nan
    s = (str(x).replace('$', '').replace(',', '')
                .replace('(', '-').replace(')', '')
                .replace(' ', '').replace('%', '').strip())
    if s == '-':
        return 0.0
    try:
        return float(s)
    except ValueError:
        return np.nan


# ---------------------------------------------------------------------------
# Load SEC metadata
# ---------------------------------------------------------------------------
print("Loading SEC metadata...")
meta = pd.read_csv('output/metadata.csv')
meta['acc'] = meta['accession_number'].astype(str)
meta['dt']  = pd.to_datetime(meta['report_period'].astype(str),
                              format='%Y%m%d', errors='coerce')
meta_map      = meta.set_index('acc')['company_name'].to_dict()
meta_date_map = meta.set_index('acc')['dt'].to_dict()


# ---------------------------------------------------------------------------
# Generic metric extractor — reads raw SEC table CSVs
# ---------------------------------------------------------------------------
def extract_metric(tables: list, patterns: list,
                   col_name: str, aggregate: str = 'max') -> pd.DataFrame:
    """
    Search one or more structured SEC table CSVs for rows matching any of the
    given regex patterns and return the matched numeric value per accession.

    Parameters
    ----------
    tables    : list of table filenames (without 'output/' prefix or '.csv')
    patterns  : list of regex strings to match against the concatenated label
    col_name  : name for the output column; also used for the disk cache file
    aggregate : 'max' (default) or 'sum' across matched rows per accession

    Returns
    -------
    DataFrame with columns ['acc', col_name]
    """
    cache_path = f'{OUT}/cache_{col_name}.csv'
    if os.path.exists(cache_path):
        print(f"  [{col_name}] loaded from cache.")
        return pd.read_csv(cache_path)

    all_data = []
    regex    = re.compile('|'.join(patterns), re.IGNORECASE)

    for table_name in tables:
        path = f'output/{table_name}.csv'
        if not os.path.exists(path):
            continue
        header     = pd.read_csv(path, nrows=0)
        label_cols = [c for c in header.columns if c.startswith('label')]
        val_cols   = [c for c in header.columns if c.startswith('col_')]
        if 'dollar_amount' in header.columns:
            val_cols.append('dollar_amount')

        df = pd.read_csv(path,
                         usecols=['accession_number'] + label_cols + val_cols,
                         low_memory=False)
        df['full_label'] = (df[label_cols].fillna('')
                                          .agg(' '.join, axis=1)
                                          .str.strip())
        matches = df[df['full_label'].str.contains(regex, na=False)].copy()

        if not matches.empty:
            try:
                matches['val'] = matches[val_cols].map(clean_money).max(axis=1)
            except AttributeError:   # older pandas
                matches['val'] = matches[val_cols].applymap(clean_money).max(axis=1)

            matches = matches[matches['val'] > 0]
            if not matches.empty:
                all_data.append(matches[['accession_number', 'val']])

    if not all_data:
        return pd.DataFrame(columns=['acc', col_name])

    combined      = pd.concat(all_data)
    combined['acc'] = combined['accession_number'].astype(str)
    agg_fn        = 'max' if aggregate == 'max' else 'sum'
    res           = (combined.groupby('acc')['val']
                              .agg(agg_fn)
                              .reset_index()
                              .rename(columns={'val': col_name}))
    res.to_csv(cache_path, index=False)
    return res


# ---------------------------------------------------------------------------
# Extract pool-level metrics from SEC filings
# ---------------------------------------------------------------------------
print("Extracting initial pool sizes...")
initial_df = extract_metric(
    ['table_4_noteholder', 'table_5_note_balance'],
    [r'Initial Pool Balance', r'Original Pool Balance',
     r'Initial Aggregate Principal', r'Cut-[Oo]ff Date Pool Balance',
     r'Aggregate Initial Principal'],
    'initial_pool_size'
)

print("Extracting cleanup call amounts...")
call_df = extract_metric(
    ['table_4_noteholder', 'table_5_note_balance'],
    [r'Clean[- ]?[Uu]p [Cc]all', r'Optional [Rr]edemption',
     r'Optional [Pp]urchase', r'Cleanup [Pp]urchase',
     r'Clean up [Cc]all', r'Optional [Cc]lean'],
    'cleanup_call_amount'
)

print("Extracting remaining pool balances...")
rem_df = extract_metric(
    ['table_4_noteholder', 'table_5_note_balance'],
    [r'End of Period Pool Balance', r'Ending Pool Balance',
     r'Ending Aggregate Principal Balance',
     r'Aggregate Note Balance at the end'],
    'remaining_pool_balance'
)

# ---------------------------------------------------------------------------
# Build pool-level summary (used by future plots; not directly used in Plot 1)
# ---------------------------------------------------------------------------
pool_stats = pd.DataFrame({'acc': meta['acc'].unique()})
for frame in [initial_df, call_df, rem_df]:
    pool_stats = pool_stats.merge(frame, on='acc', how='left')

pool_stats['company_name'] = pool_stats['acc'].map(meta_map)
pool_stats['dt']            = pool_stats['acc'].map(meta_date_map)
pool_stats['ym']            = pool_stats['dt'].dt.strftime('%Y-%m')
pool_stats['brand']         = pool_stats['company_name'].apply(get_brand)

# Pin initial pool size to the historical maximum for each trust
pool_max   = pool_stats.groupby('company_name')['initial_pool_size'].max().reset_index()
pool_stats = (pool_stats.drop(columns='initial_pool_size')
                        .merge(pool_max, on='company_name', how='left'))
valid_stats = (pool_stats.dropna(subset=['dt', 'company_name'])
                         .sort_values(['company_name', 'dt']))

n_calls = (valid_stats['cleanup_call_amount'] > 0).sum()
print(f"Found {n_calls} filing-periods with cleanup call amounts.")


# ===========================================================================
# PLOT 1  —  Annual Interest vs. Total Principal Collections, by Issuer Brand
# ===========================================================================
#
# Each point represents one ABS trust for one calendar year.
#
# X-axis: Annual Total Principal Collections ($ M)
#   = scheduled amortisation + voluntary prepayments + recoveries
#     + liquidation proceeds.
#   Using only scheduled amortisation would understate cash flows
#   in pools with high prepayment speeds (CPR).
#
# Y-axis: Annual Interest Collections ($ M)
#
# Guide line: ~5 % interest/principal ratio.
#   Prime auto pools (fast CPR) cluster near or below this line.
#   Subprime pools (slow CPR, high WAC — e.g. Santander) plot above it.
#
# Source: output/final_abs_summary_dr_honkanen.csv
# ===========================================================================
print("\nGenerating scatter plot...")

fs = pd.read_csv('output/final_abs_summary_dr_honkanen.csv', low_memory=False)
if 'poolname' in fs.columns:
    fs = fs.rename(columns={'poolname': 'company_name'})

fs['brand']   = fs['company_name'].apply(get_brand)
fs['date_dt'] = pd.to_datetime(fs['date'], errors='coerce')
fs['year']    = fs['date_dt'].dt.year

# Interest
fs['interest'] = pd.to_numeric(fs['totalInterest'], errors='coerce').fillna(0)

# Total principal: prefer the pre-computed totalPrincipal column;
# fall back to summing components if it is missing or zero.
fs['total_principal'] = pd.to_numeric(fs['totalPrincipal'],
                                       errors='coerce').fillna(0)
fs['principal_fallback'] = (
    pd.to_numeric(fs['principalCollections'],       errors='coerce').fillna(0) +
    pd.to_numeric(fs['prepaymentsInFullCollected'],  errors='coerce').fillna(0) +
    pd.to_numeric(fs['recoveries'],                  errors='coerce').fillna(0) +
    pd.to_numeric(fs['liquidationProceeds'],          errors='coerce').fillna(0)
)
fs['principal'] = np.where(fs['total_principal'] > 0,
                            fs['total_principal'],
                            fs['principal_fallback'])
fs['months'] = 1   # each row is one monthly servicer report

# Aggregate to annual totals per trust
annual = (
    fs.groupby(['company_name', 'brand', 'year'], as_index=False)
      .agg(annual_interest  = ('interest',   'sum'),
           annual_principal = ('principal',  'sum'),
           month_count      = ('months',     'sum'))
)

# Quality filters
annual = annual[annual['month_count'] >= 6]          # require ≥6 months
annual = annual[(annual['annual_interest']  > 0) &
                (annual['annual_principal'] > 0)]
annual = annual[annual['brand'] != 'OTHER']

# Sanity cap: implied ratio > 30 % suggests a reporting error
annual['eff_rate'] = annual['annual_interest'] / annual['annual_principal']
annual = annual[annual['eff_rate'] <= 0.30]

brands_present = sorted(annual['brand'].unique())
n_brands       = len(brands_present)
print(f"  {n_brands} brands on scatter: {brands_present}")
assert n_brands >= 20, (
    f"Only {n_brands} brands found (target ≥ 20). "
    "Add additional issuers to get_brand()."
)

# ── Draw scatter ─────────────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(13, 11))

for b in brands_present:
    sub = annual[annual['brand'] == b]
    ax.scatter(
        sub['annual_principal'] / 1e6,
        sub['annual_interest']  / 1e6,
        alpha=0.65, s=52,
        color=brand_color(b),
        edgecolors='white', linewidths=0.3,
        label=b, zorder=3
    )

# ~5 % interest/principal guide line (typical prime auto ABS)
max_p = annual['annual_principal'].max() / 1e6
ax.plot([0, max_p], [0, max_p * 0.05],
        color='#cccccc', linestyle='--', linewidth=1.4,
        alpha=0.5, label='~5 % Interest/Principal Guide')

# Annotation explaining the subprime cluster
ax.annotate(
    "Subprime issuers (e.g. Santander)\nsit above guide — high WAC, slow CPR",
    xy=(600, 165), xytext=(750, 210),
    fontsize=8, color='#ffaaaa',
    arrowprops=dict(arrowstyle='->', color='#ffaaaa', lw=0.8),
)

ax.set_title(
    'SEC ABS Auto Pools: Annual Interest vs. Total Principal Collections\n'
    '(principal = sched. amort. + prepayments + recoveries; '
    'each point = one trust-year, 2005–2024)',
    fontweight='bold', pad=14
)
ax.set_xlabel('Annual Total Principal Collections ($ Millions)', fontweight='bold')
ax.set_ylabel('Annual Interest Collections ($ Millions)',        fontweight='bold')
ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f'${x:,.0f}M'))
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f'${x:,.0f}M'))
ax.legend(loc='upper left', facecolor='#1a1a1a', edgecolor='#444',
          framealpha=0.9, ncol=2, fontsize=8)

plt.tight_layout()
out_path = f'{OUT}/01_scatter_by_brand.png'
plt.savefig(out_path, dpi=300, bbox_inches='tight')
plt.close()
print(f"  Saved: {out_path}  ({n_brands} brands, {len(annual):,} trust-years)")
print("\nDone.")
